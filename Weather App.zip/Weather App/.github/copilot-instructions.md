# Weather API Project - AI Coding Agent Instructions

## Project Overview
A modern web-based weather application using the WeatherAPI free tier. Single-file HTML5 project with vanilla JavaScript, CSS3, and responsive design.

## Architecture & Key Components

### Technology Stack
- **Frontend**: HTML5, CSS3 (Glassmorphism design), Vanilla JavaScript (ES6+)
- **External APIs**: WeatherAPI.com (free tier with API key: `fd5e07d2ea254e6c87384509251411`)
- **Styling**: Multiple Google Fonts (Poppins, Montserrat, Inter), linear gradients, backdrop filters
- **Storage**: Browser localStorage for favorites persistence

### Main Components
1. **Search Interface** - Input field with Enter-key support for city search
2. **Weather Display** - Shows 6+ weather metrics (temp, humidity, wind, feels-like, visibility, pressure, dewpoint)
3. **Favorites System** - Save/load/remove favorite cities using localStorage
4. **Error Handling** - User-friendly error messages with visual feedback
5. **Responsive Layout** - Two-column grid (desktop) → single column (mobile)

## Critical Implementation Patterns

### Weather Data Fetching
```javascript
// Pattern: CORS-safe fetch with proper error handling
const url = `https://api.weatherapi.com/v1/current.json?key=API_KEY&q=${encodeURIComponent(city)}&aqi=yes`;
const response = await fetch(url);
if (!response.ok) throw new Error('City not found');
const data = await response.json();
```

### Favorites Management
- **Storage**: `localStorage.getItem/setItem('weatherFavorites')` - JSON stringified array
- **Load**: Parse on page load; update UI immediately after modifications
- **Pattern**: Always call `displayFavorites()` after save operations

### UI State Management
- Show/hide `#result` div based on fetch success
- Use `#errorMsg` div for both errors (red) and notifications (green)
- Loading state: Show spinner with message during fetch

## Developer Workflows

### Adding New Weather Metrics
1. Add new `<div class="detail-item">` in `.weather-details` grid
2. Add corresponding `id` element (e.g., `id="uvIndex"`)
3. Update the fetch response handler: `document.getElementById('uvIndex').innerText = data.current.uv;`

### Styling Approach
- **Font Families**: Poppins (body), Montserrat (headers), Inter (numbers/labels)
- **Color Scheme**: Purple gradient (`#667eea` to `#764ba2`) with glassmorphism overlays
- **Responsive Breakpoint**: 768px (single column below)
- **Animations**: `fadeIn` (container), `slideUp` (weather-box), `shake` (errors)

### Error/Success Feedback Pattern
```javascript
// Use showError() for failures, showNotification() for success
showError('❌ City not found');  // Red background
showNotification('✓ Added to favorites!');  // Green background
```

## API & Integration Points

### WeatherAPI Endpoints
- **Endpoint**: `https://api.weatherapi.com/v1/current.json`
- **Required Params**: `key`, `q` (city), `aqi=yes` (air quality)
- **Response**: `.location` (name, country), `.current` (temp, condition, wind, humidity, etc.)
- **Limits**: Free tier ~1M requests/month; use encodeURIComponent for city names

### Browser APIs Used
- `localStorage` - Persist favorites across sessions
- `fetch()` - Async HTTP requests
- `addEventListener('keypress')` - Enter-key search support
- `.classList` - Dynamic styling (not currently used; can add for theme switching)

## Project-Specific Conventions

### File Structure
```
Weather API/
├── index.html (single file - all HTML, CSS, JS)
├── .github/
│   └── copilot-instructions.md (this file)
```

### Naming Conventions
- **IDs**: kebab-case for HTML elements (`#city`, `#errorMsg`, `#favoritesList`)
- **Functions**: camelCase (`getWeather()`, `addToFavorites()`, `showNotification()`)
- **CSS Classes**: kebab-case with semantic naming (`.weather-box`, `.detail-item`, `.btn-favorite`)

### Common Modifications
- **Change colors**: Update `linear-gradient(135deg, #667eea 0%, #764ba2 100%)` in body style
- **Change fonts**: Import from `fonts.googleapis.com` and update `font-family` declarations
- **Add temperature unit toggle**: Modify temp display and use `data.current.temp_f` for Fahrenheit
- **Add more weather details**: WeatherAPI returns many fields not currently displayed (UV, air quality, etc.)

## Testing & Debugging

### Manual Testing Checklist
- ✓ Search works with valid city names (e.g., "London", "New York")
- ✓ Error message appears for invalid cities
- ✓ Add/remove favorites works; persists after page reload
- ✓ Responsive: toggle DevTools device emulation (768px breakpoint)
- ✓ Enter key triggers search
- ✓ Weather icon loads from https CDN

### Common Issues
- **CORS errors**: Ensure using `https://` (not `http://`) for API
- **Favorites not persisting**: Check localStorage isn't disabled; verify JSON serialization
- **Weather icon 404**: API returns relative URLs; prepend `https:` when setting `src`
